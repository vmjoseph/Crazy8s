package crazy8s;

import crazy8s.card.Card;
import crazy8s.card.Deck;
import crazy8s.player.Command;
import crazy8s.player.Human;
import crazy8s.player.IPlayer;
import crazy8s.player.Opponent;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Game class which implements Crazy 8s play rules.
 *
 * @authors Vallie Joseph, Zachary Recolan and Lizeth Sanchez
 */
public class Game {

    protected ArrayList<IPlayer> players = new ArrayList<>();
    protected Deck deck = new Deck();
    protected ArrayList<Card> myhand;

    /**
     * Shuffles player turn at the beginning of game
     */
    public Game() {
        players.add(new Human());
        players.add(new Opponent());
        Collections.shuffle(players);
    }

    /**
     * Starts the game loop
     */
    public void go() {
        this.deal();
        Card discard = deck.draw();
        deck.discard(discard);
        System.out.println("Discard card is " + discard);
        this.distribute(discard);
        while (true) {
            loop:
            for (IPlayer player : players) {
                this.gameOverCheck();
                do {
                    if (player instanceof Human) {
                        Game.show(player);
                    }
                    int command = player.getCommand();
                    switch (command) {
                        case Command.DRAW:
                            Card card = deck.draw();
                            player.getHand().add(card);
                            for (IPlayer tempPlayer : players) {
                                tempPlayer.drew(player, card);
                            }
                            break;
                        case Command.SHOW:
                            System.out.println("Discard card is " + player.getDiscard());
                            break;
                        case Command.QUIT:
                            System.exit(0);
                        case Command.NO_COMMAND:
                            System.out.println("Invalid command. Please try again");
                            break;
                        case Command.REFRESH:
                            System.out.println("");
                            System.out.println("");
                            System.out.println("");
                            System.out.println("");
                            System.out.println("");
                            System.out.println("");
                            System.out.println("");
                            System.out.println("");
                            System.out.println("");
                            
                            if (deck.discards.size() == 1) {
                                System.out.println("There is " + deck.cards.size() + "card in the deck.");
                            } else {
                                System.out.println("There are " + deck.cards.size() + " cards in the deck.");
                            }
                            if (deck.discards.size() == 1) {
                                System.out.println("There is " + deck.discards.size() + " card in the discard pile.");
                            } else {
                                System.out.println("There are " + deck.discards.size() + " cards in the discard pile.");
                            }
                            if (players.get(1).getHand().size() == 1) {
                                System.out.println("There is " + players.get(1).getHand().size() + " card in the deck.");
                            } else {
                                System.out.println("There are " + players.get(1).getHand().size() + " cards in the " + players.get(1) + "'s hand.");
                            }
                            System.out.println("Discarded card is " + player.getDiscard());
                            break;
                        default:
                            this.cardPlayed(player, command);
                            continue loop;
                    }
                } while (true);
            }
        }
    }

    /**
     * Deals the cards at the beginning of the game.
     *
     */
    protected void deal() {
        for (int index = 0; index < 8; index++) {
            for (IPlayer player : players) {
                Card card = deck.draw();
                player.getHand().add(card);
            }
        }
    }

    /**
     * Converts face cards to 10 points and calculates score of players.
     *
     * @param player Player hand points
     * @return Total amount of points (pointsEarned)
     */
    protected int scoreGame(IPlayer player) {
        int pointsEarned = 0;
        for (IPlayer tempPlayer : players) {
            if (player != tempPlayer) {
                for (Card card : tempPlayer.getHand()) {
                    if (card.getRank() == 8) {
                        pointsEarned += 50;
                    } else if (card.getRank() == 11) {
                        pointsEarned += 10;
                    } else if (card.getRank() == 12) {
                        pointsEarned += 10;
                    } else if (card.getRank() == 13) {
                        pointsEarned += 10;
                    } else {
                        pointsEarned += card.getRank();
                    }
                }
            }
        }
        player.setScore(player.getScore() + pointsEarned);
        return pointsEarned;
    }

    /**
     * Checks to see if the game is over, implements game over if the hand is
     * empty
     */
    protected void gameOverCheck() {
        for (IPlayer player : players) {
            if (player.getHand().isEmpty()) {
                gameOver(player);
            }
        }
    }

    /**
     * When the game is over, selects winner and outputs both players scores.
     * Begins new game
     *
     * @param winner Player who has no cards
     */
    protected void gameOver(IPlayer winner) {
        System.out.println("Game over");
        System.out.println(winner + " scored " + this.scoreGame(winner));
        for (IPlayer player : players) {
            System.out.println("~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~");
            System.out.println(player + " score : " + player.getScore());
            System.out.println(player + " had " + player.getHand().size() + " cards");
            System.out.println(player.getHand());
            if (player.getHand().size() == 0) {
                System.out.println(winner + " has no cards left. ");
            }
        }
        System.out.println("@~~~|@~~~|@~~~|@~~~|@~~~|@~~~|@~~~|");
        System.out.println("Starting new game...");
        Game game = new Game();
        game.go();
    }

    /**
     * Assigns what is played to the correct player.
     *
     * @param player All players implementing IPlayer
     * @param card Cards dealt in the beginning
     */
    protected void distribute(IPlayer player, Card card) {
        for (IPlayer tempPlayer : players) {
            tempPlayer.played(player, card);
        }
    }

    /**
     * Assigns the discarded to the correct player
     *
     * @param discard Card placed in the discard pile through the player
     */
    protected void distribute(Card discard) {
        for (IPlayer player : players) {
            player.played(discard);
        }
    }

    /**
     * Gets the card played for each player and looks for an 8. If an 8 is
     * present, asks for the player to set the suit
     *
     * @param player Human or Opponent
     * @param command Grabs the method for set suit when 8 is played
     */
    protected void cardPlayed(IPlayer player, int command) {
        Card played = player.getHand().remove(command);
        deck.discard(played);
        if (played.getRank() == 8) {
            int suit = player.getSuit();
            played.setSuit(suit);
            for (IPlayer tempPlayer : players) {
                tempPlayer.setSuit(suit);
            }
        }
        this.distribute(player, played);
    }

    /**
     * Shows the player's hand through index list and outputs the score
     *
     * @param player Player's score index
     */
    public static void show(IPlayer player) {
        ArrayList<Card> hand = player.getHand();
        System.out.println(player);
        System.out.println("Score: " + player.getScore());
        for (int index = 0; index < hand.size(); index++) {
            System.out.println((index + 1) + ". " + hand.get(index));
        }
    }

    /**
     *
     * @param player
     * @param card
     */
//    public static int sortedSuit (IPlayer player,Card card){
//       player.getHand();
//        if (player.getCommand("Draw"){
//           Collections.sort(player.getSuit());
//        } else {
//          return  "";
//        }
//        return Command.NO_COMMAND;
//   }
    /**
     *
     * @param player
     * @param card
     */
//    public static void sortedDraw (IPlayer player,Card card){
//        List <Card> sortedDraw =player.getHand();
//        
//        
//    }
    /**
     * Posts when the game initializes
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Welcome!");
        System.out.println("Enter index of card to play | (s)how hand | (d)raw card | (q)uit game | (r)efresh and display game stats");
        Game game = new Game();
        game.go();
    }
}
