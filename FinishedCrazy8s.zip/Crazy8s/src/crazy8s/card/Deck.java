/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crazy8s.card;

import java.util.ArrayList;
import java.util.Random;

/**
 * Represents a card deck.
 *
 * @authors Vallie Joseph, Zachary Recolan and Lizeth Sanchez
 */
public final class Deck {

    int rank;
    int suit;

    Random ran = new Random();
    public ArrayList<Card> cards = new ArrayList<>();
    public ArrayList<Card> discards = new ArrayList<>();
/**
 * Constructs the deck and sets up rank and suit parameters 
 * implements shuffle function
 */
    public Deck() {
        for (int r = 1; r <= 13; r++) {
            for (int s = 1; s <= 4; s++) {
                Card card = new Card(r, s);
                cards.add(card);
            }
        }
        this.shuffle();
    }
    /**
     * Re-shuffles the deck of empty when a card is drawn
     * @return Shuffling of cards and deals player a recycled card
     */

    public Card draw() {
        if (!(cards.isEmpty())) {

            Card card = cards.remove(0);
            return card;
        }
     
        this.discardToDraw();
        this.shuffle();
        Card card = cards.remove(0);
        return card;
        
    }
/**
 * Creates a discarded pile to be recycled after the deck runs out
 * @param card Arraylist of discarded cards
 */
    public void discard(Card card) {
        discards.add(0, card);
        rank = card.rank;
        suit = card.suit;
    }
    /*
    Reshuffles the deck and notifies player
    */
    
    public void discardToDraw(){
        System.out.println("Reshuffling deck!");
         for (int i = discards.size() - 1; i > 0; i--) {
            Card card = discards.remove(i);
            cards.add(card);

        }
    }
    
  /**
   * Grabs the discarded rank
   * @return Rank of discarded card
   */  

    public int getDiscardRank() {
        return rank;
    }
    /**
     * Grabs the discarded suit.
     * @return Suit of the discarded card.
     */

    public int getDiscardSuit() {
        return suit;
    }
    /**
     * Sets the suit for incoming cards of the discard pile
     * @param suit After 8 is played
     */

    public void setDiscardSuit(int suit) {
        this.suit = suit;
    }
/**
 * Shuffles the cards
 */
    public void shuffle() {
        for (int index = 0; index < cards.size(); index++) {
            Card card1 = cards.get(index);

            int lottery = ran.nextInt(cards.size());

            Card card2 = cards.get(lottery);

            cards.set(index, card2);

            cards.set(lottery, card1);
        }
    }
    /**
     * Sets the card index to a string
     * @return String of cards in index
     */

    @Override
    public String toString() {
        String s = "";
        for (int index = 0; index <= 10; ++index) {
            Card card = cards.get(index);

            String t = card + "\n";

            s = s + (index + 1) + ". " + t;
        }
        return s;
    }
/**
 * Creates a new deck
 * @param args 
 */
    public static void main(String[] args) {
        Deck deck = new Deck();
        System.out.println(deck);
    }
}
