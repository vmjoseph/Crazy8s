/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crazy8s.card;

/**
 *
 * @authors Vallie Joseph, Zachary Recolan and Lizeth Sanchez
 */
public class Card implements ICard {
    public final static int CLUBS = 1;
    public final static int DIAMONDS = 2;
    public final static int HEARTS = 3;
    public final static int SPADES = 4;
    
    int rank;
    int suit;
/**
 * Prints out cards for testing purposes 
 * @param args 
 */
    public static void main(String[] args) {
        Card card = new Card(8, 1);
        System.out.println(card);

        Card card2 = new Card(11, 2);
        System.out.println(card2);

        Card card3 = new Card(1, 4);
        System.out.println(card3);

    }
    public int getSuit;
/**
 * Constructs the card
 * @param rank References rank from ICard
 * @param suit References suit from ICard
 */
    public Card(int rank, int suit) {
        this.rank = rank;
        this.suit = suit;
    }
/**
 * Grabs the rank of the card
 * @return the card's rank
 */
    @Override
    public int getRank() {
        return rank;
    }
/**
 * Grabs the suit of the card
 * @return the card's suit
 */
    @Override
    public int getSuit() {
        return suit;
    }
    /**
     * Sets the suit for each card
     * @param suit of card
     */
    public void setSuit(int suit){
        this.suit = suit;
    }
/**
 * Overrides the basic string method to implement our toString
 * @return the actual card rather than index numbers
 */
    @Override
    public String toString() {
        return decodeRank() + " of " + decodeSuit();
    }
/**
 * Decodes the rank to a string
 * @return Stringed Rank
 */
    public String decodeRank() {
        if (rank == 1) {
            return "Ace";
        }

        if (rank == 11) {
            return "Jack";
        }

        if (rank == 12) {
            return "Queen";
        }

        if (rank == 13) {
            return "King";
        }

        if ((rank >= 2) && (rank <= 10)) {
            return rank + "";
        }

        return "";
    }
/**
 * Decodes the suit to a string
 * @return Stringed Suit
 */
    public String decodeSuit() {
        if (suit == CLUBS) {
            return "Clubs";
        }

        if (suit == DIAMONDS) {
            return "Diamonds";
        }

        if (suit == HEARTS) {
            return "Hearts";
        }

        if (suit == SPADES) {
            return "Spades";
        }

        return "";
    }
}
