package crazy8s.test;

import crazy8s.Game;
import crazy8s.card.Card;
import crazy8s.card.Deck;
import crazy8s.player.Command;
import crazy8s.player.Opponent;
import java.util.ArrayList;

/**
 * This class tests draw from the deck.
 */
public class Test02 {
    public static void main(String[] args) {
        Deck deck = new Deck();
        
        Opponent opponent = new Opponent();
        
        ArrayList<Card> hand = opponent.getHand();
        
        for(int count=0; count < 8; count++) {
            Card card = deck.draw();
            hand.add(card);
        }
        
        hand.remove(6);
        
        Game.show(opponent);
        
        Card discarded = new Card(10,Card.HEARTS);
        
        PlayTester tester = new PlayTester();
        
        opponent.played(tester, discarded);
        
        int index = opponent.getCommand();
        
        System.out.println("index = "+index);
        assert index == Command.DRAW;
               
        System.out.println("PASSED!");
    }
}
