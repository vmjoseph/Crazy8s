package crazy8s.test;

import crazy8s.Game;
import crazy8s.card.Card;
import crazy8s.card.Deck;
import crazy8s.player.Opponent;
import java.util.ArrayList;

/**
 * This class tests for rank match.
 */
public class Test00 {
    public static void main(String[] args) {
        Deck deck = new Deck();
        
        Opponent opponent = new Opponent();
        
        ArrayList<Card> hand = opponent.getHand();
        
        for(int count=0; count < 8; count++) {
            Card card = deck.draw();
            hand.add(card);
        }
        
        Game.show(opponent);
        
        Card discarded = new Card(4,Card.HEARTS);
        
        PlayTester tester = new PlayTester();
        
        opponent.played(tester, discarded);
        
        int index = opponent.getCommand();
        
        assert index >= 0;
        assert index < hand.size();
               
        Card card = hand.get(index);
        System.out.println(opponent+" played "+card);
        
        assert discarded.getRank() == card.getRank();
        
        System.out.println("PASSED!");
    }
}
