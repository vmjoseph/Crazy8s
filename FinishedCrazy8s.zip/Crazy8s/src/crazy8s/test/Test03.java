package crazy8s.test;

import crazy8s.Game;
import crazy8s.card.Card;
import crazy8s.card.Deck;
import crazy8s.player.Opponent;
import java.util.ArrayList;

/**
 * This class tests playing an 8.
 */
public class Test03 {
    public static void main(String[] args) {
        Deck deck = new Deck();
        
        Opponent opponent = new Opponent();
        
        ArrayList<Card> hand = opponent.getHand();
        
        for(int count=0; count < 8; count++) {
            Card card = deck.draw();
            hand.add(card);
        }
        
        // Remove the lone hearts (3H)
        hand.remove(6);
        
        // Add an eight clubs
        hand.add(new Card(8,Card.CLUBS));
        
        Game.show(opponent);
        
        Card discarded = new Card(10,Card.HEARTS);
        
        PlayTester tester = new PlayTester();
        
        opponent.played(tester, discarded);
        
        int index = opponent.getCommand();
        
        assert index >= 0 && index < hand.size();
               
        Card card = hand.get(index);
        System.out.print(opponent+" played "+card);
        
        assert card.getRank() == 8;
        
        int suit = opponent.getSuit();
        System.out.println(", suit = "+suit);
        
        assert suit == Card.DIAMONDS;
        
        System.out.println("PASSED!");
    }
}
