package crazy8s.player;

import crazy8s.card.Card;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * This class implements a human player.
 *
 * @authors Vallie Joseph, Zachary Recolan and Lizeth Sanchez
 */
public class Human implements IPlayer {

    /**
     * My score
     */
    private static int score = 0;

    /**
     * My hand
     */
    ArrayList<Card> myhand;

    /**
     * Buffered reader connect to the standard input device
     */
    BufferedReader br;
    public Card discarded;

    /**
     * Constructs human player which has access to the keyboard.
     */
    public Human() {
        try {
            myhand = new ArrayList<>();

            br = new BufferedReader(new InputStreamReader(System.in));
        } catch (Exception e) {
            System.err.println("constructor failed: " + e);
        }
    }

    /**
     * Gets the encoded command from the player. That is, the player provides
     * some input in the form of "s", "r", "d", "q", or a number string "1",
     * "2", ... "52", and this method converts this input into an integer. The
     * letter commands are in the class, Command. A number represents itself as
     * an index in the player's hand.
     *
     * @return Encoded command
     */
    @Override
    public int getCommand() {
        if (br == null) {
            return 0;
        }
        

        try {
            // Pulls up the line reader and waits for user input
            System.out.print("Input command => ");
            String input = br.readLine();
            Integer cmd = encodeCommand(input);
            
            return cmd;
        } catch (Exception e) {

        }
        return Command.NO_COMMAND;
    }

    /**
     * Encodes a command to a string.
     *
     * @param input Grabs the input from the user and converts it to a command
     * @return The command that the human inputed and checks it
     * command
     */
    protected int encodeCommand(String input) {
        input = input.toLowerCase().trim();
        if (input.equals("s") || input.equals("show")) {
            return Command.SHOW;
        } 
        else if (input.equals("q") || input.equals("quit")) {
            return Command.QUIT;
        } 
        else if (input.equals("d") || input.equals("draw")) {
            if (this.canDraw()) {return Command.DRAW;}
        }
        else if (input.equals("r") || input.equals("refresh"))
            return Command.REFRESH;
        else {
            if (isValidPlay(Integer.parseInt(input)-1)) {
                return Integer.parseInt(input)-1;
            }
        }
        return Command.NO_COMMAND;
    }
/**
 * Checks the hand for a valid play, if it is valid, draw will not call
 * if not valid, draw can be called
 * @param index
 * @return 
 */
    protected boolean isValidPlay(int index) {
        if (discarded.getRank() == myhand.get(index).getRank()) {return true;}
        else if (discarded.getSuit() == myhand.get(index).getSuit()) {return true;}
        else if (myhand.get(index).getRank() == 8) {return true;}
        return false;
    }
    /**
     * Encodes the choose suit/set suit command for 8 cards
     * @param input
     * @return Suit choices
     */
    protected int encode8Command(String input) {
        input = input.toLowerCase().trim();

        if (input.equals("c") || input.equals("clubs")) {
            return Card.CLUBS;
        } else if (input.equals("d") || input.equals("diamonds")) {
            return Card.DIAMONDS;
        } else if (input.equals("h") || input.equals("hearts")) {
            return Card.HEARTS;
        } else if (input.equals("s") || input.equals("spades")) {
            return Card.SPADES;
        }
        return Command.NO_COMMAND;
    }
/**
 * Checks to see if the player has a playable card, if so, cancels draw and
 * outputs a string.
 * @return 
 */
    protected boolean canDraw() {
            if (this.hasPlayableCard()) {
                System.out.println("You can make a play");
                return false;
            }
            return true;
    }

    /**
     * Gets my hand
     */
    @Override
    public ArrayList<Card> getHand() {
        return myhand;
    }

    /**
     * Outputs the player's last played card
     *
     * @param player Play who played this card.
     * @param card Card played by the player.
     */
    @Override
    public void played(IPlayer player, Card card) {
        this.discarded = card;
        if (card.getRank() == 8) {
            System.out.println(player + " changed suit to " + card.decodeSuit());
        }
        else {
            System.out.println(player + " played a " + card);
        }
    }
/**
 * Sets the discarded card
 * @param card that was discarded
 */
    @Override
    public void played(Card card) {
        this.discarded = card;
    }

    /**
     * Outputs the player's draw
     *
     * @param player Player who drew this card.
     * @param card that is added to the hand
     */
    @Override
    public void drew(IPlayer player, Card card) {
        System.out.println(player + " drew a card");
    }
/**
 * Gets the Suit that the player selects
 * @return Sets the suit
 */
    @Override
    public int getSuit() {
        try {
            System.out.print("Enter Suit: (c)lubs, (d)iamonds, (h)earts, (s)pades => ");
            String command = br.readLine();

            int cmd = this.encode8Command(command);
            if (cmd == Command.NO_COMMAND) {
                System.out.println("Invalid command. Try again");
                return getSuit();
            }
            return cmd;

        } catch (Exception e) {

        }
        return Command.NO_COMMAND;
    }
/**
 * This is the set suit called by the get Suit. It is the method that grabs the 
 * selected suit
 * @param suit 
 */
    @Override
    public void setSuit(int suit) {
        discarded.setSuit(suit);
    }

    /**
     * Converts the player to a string.
     */
    @Override
    public String toString() {
        return "HUMAN";
    }

    /**
     * Test the human player
     */
    public static void main(String[] args) {
        Human player = new Human();

        while (true) {
            Integer command = player.getCommand();
            System.out.println(player + ": sent encoded command " + command);

            if (command == Command.QUIT) {
                break;
            }
        }
    }
/**
 * Grabs the score from Game
 * @return Score
 */
    @Override
    public int getScore() {
        return score;
    }
/**
 * Sets the score from Game
 * @param score The final score
 */
    @Override
    public void setScore(int score) {
        this.score = score;
    }
/**
 * Grabs the card that was discarded
 * @return last discarded card
 */
    public Card getDiscard() {
        return discarded;
    }
/**
 * Checks to see if the player has a playable card in hand
 * @return Either gives a true or false
 */
    protected boolean hasPlayableCard() {
        for (Card card : myhand) {
            if (discarded.getRank() == card.getRank() || discarded.getSuit() == card.getSuit() || card.getRank() == 8) {
                return true;
            }
        }
        return false;
    }

}
