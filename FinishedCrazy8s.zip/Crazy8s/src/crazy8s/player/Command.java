/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crazy8s.player;

/**
 * Valid commands "other" not including card indexes.
 * Human players use all of these commands whereas
 * artificially intelligent computer players use
 * only DRAW and card index commands.
 * @authors Vallie Joseph, Zachary Recolan and Lizeth Sanchez
 */
public class Command {
  public final static int NO_COMMAND = -1;
  public final static int SHOW = 53;
  public final static int REFRESH = 54;
  public final static int DRAW = 55;
  public final static int QUIT = 56;
}
